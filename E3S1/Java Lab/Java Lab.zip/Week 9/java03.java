// 3. Write a program to rethrow an exception – Define methods one() & two(). Method two()
// should initially throw an exception. Method one() should call two(), catch the exception and
// rethrow it Call one() from main() and catch the rethrown .

public class java03 {
    public static void main(String[] args) {
        
        
    }
    
}
