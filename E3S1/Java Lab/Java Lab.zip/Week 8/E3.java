package RGUKT.EEE.e3;
public class E3{
	public void display(){
			System.out.println("there are 5 classes in E3");
	}
}
