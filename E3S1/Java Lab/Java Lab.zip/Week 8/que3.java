import dept.CSE;
import dept.ECE;
import dept.ME;
import dept.CE;
public class que3{
	public static void main(String[] args){
		CSE c1=new CSE();
		c1.display();
		ECE e1=new ECE();
		e1.display();
		ME m1=new ME();
		m1.display();
		CE ce1=new CE();
		ce1.display();
	}
	}
