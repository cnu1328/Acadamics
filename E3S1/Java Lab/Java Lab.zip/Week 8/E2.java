package RGUKT.EEE.e2;
public class E2{
	public void display(){
			System.out.println("there are 5 classes in E2");
	}
}
