package RGUKT.EEE.e1;
public class E1{
	public void display(){
			System.out.println("there are 5 classes in E1");
	}
}
