package dept;
public class CSE{
	public void display(){
		System.out.println("CSE subjects are DM,DBMS,FLAT,DAA,PPS,OOPS");
	}
}
