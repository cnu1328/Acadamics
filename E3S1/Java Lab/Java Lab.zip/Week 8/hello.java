package CSE_112;
public class hello{
	public void display(){
		System.out.println("hello");}
}