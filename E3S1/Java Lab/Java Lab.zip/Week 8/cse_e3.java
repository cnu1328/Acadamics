package RGUKT.CSE.E3;
public class cse_e3{
	public void display(){
			System.out.println("there are 5 clases in cse e3");
	}
}
