package org.shapes;
public class Square{
	public void getArea(double s){
		System.out.println("area of square="+s*s);
	}
	public void getPerimeter(double s){
		System.out.println("perimeter of square="+4*s);
	}
}