package dept;
public class ECE{
	public void display(){
		System.out.println("ECE subjects are AC,EDC,DEC,SS,PTSP,RF,DSP");
	}
}
