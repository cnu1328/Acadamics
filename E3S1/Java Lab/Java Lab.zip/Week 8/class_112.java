package RGUKT.CSE.E3.C3;
public class class_112{
	public void display(){
			System.out.println("there are 64 students in cse112 class");
	}
}
