package RGUKT.CSE.E1;
public class cse_e1{
	public void display(){
			System.out.println("there are 5 clases in cse e1");
	}
}
