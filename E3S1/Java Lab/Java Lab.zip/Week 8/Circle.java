package org.shapes;
public class Circle{
	public void getArea(double s){
		System.out.println("area of circle="+(3.14*s*s));
	}
	public void getPerimeter(double s){
		System.out.println("perimeter of circle="+(2*3.14*s));
	}
}