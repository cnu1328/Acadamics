package org.shapes;
public class Triangle{
	public void getArea(double b,double h){
		System.out.println("area of triangle="+(0.5*b*h));
	}
	public void getPerimeter(double a,double b,double c){
		System.out.println("perimeter of triangle="+(a+b+c));
	}
}