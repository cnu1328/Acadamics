package RGUKT.CSE.E4;
public class cse_e4{
	public void display(){
			System.out.println("there are 5 clases in cse e4");
	}
}
