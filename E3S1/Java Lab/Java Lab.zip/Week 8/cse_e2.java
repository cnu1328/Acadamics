package RGUKT.CSE.E2;
public class cse_e2{
	public void display(){
			System.out.println("there are 5 clases in cse e2");
	}
}
