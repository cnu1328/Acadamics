import RGUKT.CSE.E3.cse_e3;
public class CLASSES{
	public static void main(String args[]){
		cse_e3 c1=new cse_e3();
		c1.display();
		
	}
}
