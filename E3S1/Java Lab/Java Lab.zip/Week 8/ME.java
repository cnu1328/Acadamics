package dept;
public class ME{
	public void display(){
		System.out.println("ME subjects are KOM,SOM,THERMODYNAMICS,FLUID MECHANICS");
	}
}
