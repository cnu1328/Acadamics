package RGUKT;
public class BRANCHES{
	public void display(){
		System.out.println("RGUKT consists of 7 branches in engineering.They are CSE,ECE,EEE,MME,CIVIL,ME,CE");
	}
}
