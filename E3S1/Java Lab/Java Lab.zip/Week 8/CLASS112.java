import RGUKT.CSE.E3.C3.class_112;
public class CLASS112{
	public static void main(String args[]){
		class_112 c2=new class_112();
		c2.display();
		
	}
}
