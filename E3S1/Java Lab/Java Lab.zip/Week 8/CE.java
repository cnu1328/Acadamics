package dept;
public class CE{
	public void display(){
		System.out.println("CE subjects are I dont know");
	}
}
