package RGUKT.CSE;
public class cse1{
	public void display(){
			System.out.println("there are 4 year students in CSE branch");
	}
}
