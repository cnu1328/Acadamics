package RGUKT.EEE.e4;
public class E4{
	public void display(){
			System.out.println("there are 5 classes in E4");
	}
}
