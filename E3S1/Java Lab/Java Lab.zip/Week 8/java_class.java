import CSE_112.hello;
class java_class{
	public static void main(String args[]){
		hello h1=new hello();
		h1.display();}
}