import java.util.*;
public class java04concate {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.next();
        String b = sc.next();
        System.out.println(a.concat(b));
        

    }
}
