import java.util.*;
public class java07tolower {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.next();
        System.out.println(a);
        System.out.println(a.toLowerCase());
        
    }
}
