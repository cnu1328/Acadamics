public class java08substring {

    public static void main(String[] args) {
        
    }
}