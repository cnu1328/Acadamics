import java.awt.*;
class awt1 {
 public static void main(String args[]) {
   Frame f=new Frame("My AWT frame");
     f.setSize(1000,850);
     f.setVisible(true);
    }
}